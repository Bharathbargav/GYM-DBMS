<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gym Management</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body>
<div class="container-fluid">
  
  
  
  <div class="row">
  <div class="col-lg-12 bg-info">
  <h1 style="color:white"> GYM MANAGEMENT</h1>
  </div>
  </div>
  
  <?php include"head.php"?>
  
  <div class="row">
  <div class="col-lg-7 " style="padding:20px; ">
  <img src="image/aa.jpg" style="width:800px">
  </div>
  <div class="col-lg-5 " style="padding:20px;">
  <div  style="padding:20px;">
  <a href="newc.php"> <button class="btn btn-info btn-block">New Customer Enquiry</button></a>
 
<img src="image/mm.jpg" style="width:200px ; height:200px;">
 <img src="image/mn.jpg" style="width:200px ; height:200px;">
 <img src="image/mo.jpg" style="width:200px ; height:200px;">
 <img src="image/mk.jpg" style="width:270px ; height:200px;">
  </div>
  </div>
  </div>
  
  
  
  
  <div class="row">
  <div class="col-lg-12 bg-warning">
<?php include "bottom.php"; ?>
  
  
  </div>
  </div>
  </div>
    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
