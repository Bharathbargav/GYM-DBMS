<div class="row">
  <div class="col-lg-6 bg-warning" >
  <table class="table">
   <th><a href="adminhome.php">HOME</a></th>
   <th><a href="show_plan.php">OUR PLANS</a></th>
   <th><a href="reg.php">REGISTRATION</a></th>
   <th><a href="show_equipment.php">EQUIPMENTS</a></th>
   <th><a href="logout.php">LOGOUT</a></th>
   
  </table>
  </div>
  <div class="col-lg-6 bg-warning" ></div>
  </div>